import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown, Download, Smartphone } from 'lucide-react'
import { fadeUp, stagger } from '../lib/motion'

function PhoneMockup({ delay = 0, tilt = 8, screens }: { delay?: number; tilt?: number; screens: string[] }) {
    return (
        <motion.div
            initial={{ opacity: 0, y: 40, rotate: tilt }}
            animate={{ opacity: 1, y: 0, rotate: tilt }}
            transition={{ duration: 1, delay, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
            style={{ rotate: tilt }}
        >
            <div
                className="phone-frame relative overflow-hidden"
                style={{
                    width: 180,
                    height: 360,
                    background: 'linear-gradient(145deg, #0d1117, #141920)',
                }}
            >
                {/* Notch */}
                <div
                    className="absolute top-4 left-1/2 -translate-x-1/2 rounded-full"
                    style={{ width: 60, height: 6, background: '#1a2030' }}
                />
                {/* App screens */}
                <div className="pt-14 px-3 flex flex-col gap-2">
                    {screens.map((label, i) => (
                        <div
                            key={i}
                            className="rounded-lg"
                            style={{
                                height: i === 0 ? 80 : 40,
                                background: `linear-gradient(135deg, rgba(0,245,255,${0.08 + i * 0.02}), rgba(167,139,250,${0.06 + i * 0.02}))`,
                                border: '1px solid rgba(0,245,255,0.1)',
                            }}
                        >
                            <div className="p-2">
                                <div className="h-1.5 rounded-full mb-1" style={{ width: '60%', background: 'rgba(0,245,255,0.3)' }} />
                                <div className="h-1 rounded-full" style={{ width: '40%', background: 'rgba(255,255,255,0.1)' }} />
                            </div>
                        </div>
                    ))}
                </div>
                {/* Bottom nav indicator */}
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
                    {[1, 2, 3, 4].map((i) => (
                        <div
                            key={i}
                            className="rounded-full"
                            style={{
                                width: 6,
                                height: 6,
                                background: i === 1 ? 'var(--cyan)' : 'rgba(255,255,255,0.15)',
                            }}
                        />
                    ))}
                </div>
            </div>
        </motion.div>
    )
}

export default function Hero() {
    const { scrollY } = useScroll()
    const y1 = useTransform(scrollY, [0, 600], [0, -80])
    const y2 = useTransform(scrollY, [0, 600], [0, -120])
    const opacity = useTransform(scrollY, [0, 400], [1, 0])

    return (
        <section
            id="hero"
            className="relative min-h-screen flex items-center grid-bg overflow-hidden"
            style={{ paddingTop: 80 }}
        >
            {/* Ambient orbs */}
            <div
                className="absolute pointer-events-none"
                style={{
                    width: 600,
                    height: 600,
                    top: '10%',
                    right: '-10%',
                    background: 'radial-gradient(circle, rgba(0,245,255,0.06) 0%, transparent 70%)',
                    filter: 'blur(40px)',
                }}
            />
            <div
                className="absolute pointer-events-none"
                style={{
                    width: 400,
                    height: 400,
                    bottom: '10%',
                    left: '-5%',
                    background: 'radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)',
                    filter: 'blur(40px)',
                }}
            />

            <div className="max-w-7xl mx-auto px-6 w-full">
                <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-8">
                    {/* Left: Text */}
                    <motion.div
                        variants={stagger}
                        initial="hidden"
                        animate="visible"
                        style={{ opacity }}
                        className="flex-1 text-center lg:text-left"
                    >
                        {/* Status badge */}
                        <motion.div variants={fadeUp} className="inline-flex items-center gap-2 mb-8">
                            <div
                                className="flex items-center gap-2 px-4 py-2 rounded-full text-xs"
                                style={{
                                    background: 'rgba(0,245,255,0.08)',
                                    border: '1px solid rgba(0,245,255,0.2)',
                                    color: 'var(--cyan)',
                                    fontFamily: 'JetBrains Mono, monospace',
                                }}
                            >
                                <span className="w-2 h-2 rounded-full pulse-dot" style={{ background: 'var(--cyan)' }} />
                                Available for new opportunities
                            </div>
                        </motion.div>

                        {/* Name */}
                        <motion.div variants={fadeUp}>
                            <h1
                                className="leading-none mb-2"
                                style={{
                                    fontFamily: 'Syne, sans-serif',
                                    fontSize: 'clamp(3rem, 8vw, 5.5rem)',
                                    fontWeight: 800,
                                    letterSpacing: '-0.03em',
                                    color: 'var(--text-primary)',
                                }}
                            >
                                Aashir
                                <br />
                                <span className="gradient-text">Athar</span>
                            </h1>
                        </motion.div>

                        {/* Title */}
                        <motion.p
                            variants={fadeUp}
                            className="mb-6"
                            style={{
                                color: 'var(--text-secondary)',
                                fontFamily: 'JetBrains Mono, monospace',
                                fontSize: '0.9rem',
                                letterSpacing: '0.1em',
                            }}
                        >
                            REACT NATIVE • EXPO • TYPESCRIPT
                        </motion.p>

                        {/* Tagline */}
                        <motion.p
                            variants={fadeUp}
                            className="mb-10 max-w-xl mx-auto lg:mx-0"
                            style={{
                                color: 'var(--text-secondary)',
                                fontSize: '1.1rem',
                                lineHeight: 1.7,
                            }}
                        >
                            Senior mobile developer with{' '}
                            <span style={{ color: 'var(--text-primary)' }}>3+ years</span> building production-grade apps for{' '}
                            <span style={{ color: 'var(--cyan)' }}>50,000+ active users</span>. I architect cross-platform experiences
                            that feel native, perform fast, and scale confidently.
                        </motion.p>

                        {/* CTAs */}
                        <motion.div variants={fadeUp} className="flex flex-wrap gap-4 justify-center lg:justify-start">
                            <a href="#projects" className="btn-primary flex items-center gap-2">
                                <Smartphone size={16} />
                                Explore Projects
                            </a>
                            <a
                                href="/Aashir_Athar_Resume.pdf"
                                className="btn-secondary flex items-center gap-2"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <Download size={16} />
                                Download Resume
                            </a>
                        </motion.div>

                        {/* Stats row */}
                        <motion.div variants={fadeUp} className="flex gap-8 mt-12 justify-center lg:justify-start">
                            {[
                                { num: '3+', label: 'Years Exp.' },
                                { num: '50K+', label: 'Users Served' },
                                { num: '4', label: 'Apps Shipped' },
                            ].map(({ num, label }) => (
                                <div key={label}>
                                    <div
                                        style={{
                                            fontFamily: 'Syne, sans-serif',
                                            fontSize: '1.6rem',
                                            fontWeight: 700,
                                            color: 'var(--cyan)',
                                        }}
                                    >
                                        {num}
                                    </div>
                                    <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem', letterSpacing: '0.05em' }}>{label}</div>
                                </div>
                            ))}
                        </motion.div>
                    </motion.div>

                    {/* Right: Phone mockups */}
                    <div className="relative flex-shrink-0 hidden lg:flex items-center justify-center" style={{ height: 500, width: 380 }}>
                        <motion.div style={{ y: y1 }} className="absolute left-0 float">
                            <PhoneMockup delay={0.3} tilt={-8} screens={['feed', 'post', 'story']} />
                        </motion.div>
                        <motion.div style={{ y: y2 }} className="absolute right-0 float-delay" style={{ y: y2, top: 60 }}>
                            <PhoneMockup delay={0.5} tilt={8} screens={['map', 'donate', 'match']} />
                        </motion.div>

                        {/* Floating labels */}
                        <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 1, duration: 0.4 }}
                            className="absolute glass rounded-xl px-3 py-2 float-delay-2"
                            style={{ bottom: 80, left: '50%', transform: 'translateX(-50%)', whiteSpace: 'nowrap' }}
                        >
                            <div className="flex items-center gap-2">
                                <span style={{ color: 'var(--cyan)', fontSize: '0.7rem', fontFamily: 'JetBrains Mono' }}>60fps</span>
                                <span style={{ color: 'var(--text-secondary)', fontSize: '0.7rem' }}>buttery animations</span>
                            </div>
                        </motion.div>
                    </div>
                </div>

                {/* Scroll cue */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.5 }}
                    className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
                    style={{ color: 'var(--text-muted)' }}
                >
                    <span style={{ fontSize: '0.7rem', letterSpacing: '0.15em', fontFamily: 'JetBrains Mono' }}>SCROLL</span>
                    <motion.div animate={{ y: [0, 6, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
                        <ArrowDown size={14} />
                    </motion.div>
                </motion.div>
            </div>
        </section>
    )
}