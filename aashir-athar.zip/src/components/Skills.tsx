import { motion } from 'framer-motion'
import { fadeUp, stagger, viewportConfig } from '../lib/motion'
import { skills } from '../lib/data'

export default function Skills() {
    return (
        <section id="skills" className="py-32 relative" style={{ background: 'var(--bg-surface)' }}>
            {/* Grid background */}
            <div className="absolute inset-0 grid-bg opacity-50" />

            <div className="max-w-7xl mx-auto px-6 relative z-10">
                {/* Section label */}
                <motion.div
                    variants={fadeUp}
                    initial="hidden"
                    whileInView="visible"
                    viewport={viewportConfig}
                    className="flex items-center gap-4 mb-16"
                >
                    <span style={{ color: 'var(--cyan)', fontFamily: 'JetBrains Mono', fontSize: '0.8rem' }}>02.</span>
                    <h2 style={{ fontFamily: 'Syne', fontSize: '2rem', fontWeight: 700 }}>Technical Skills</h2>
                    <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
                </motion.div>

                <motion.div
                    variants={stagger}
                    initial="hidden"
                    whileInView="visible"
                    viewport={viewportConfig}
                    className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
                >
                    {skills.map(({ category, items }) => (
                        <motion.div
                            key={category}
                            variants={fadeUp}
                            className="glass glass-hover rounded-2xl p-6"
                        >
                            <h3
                                className="mb-4 text-sm font-semibold tracking-wider uppercase"
                                style={{ color: 'var(--cyan)', fontFamily: 'JetBrains Mono', letterSpacing: '0.1em' }}
                            >
                                {category}
                            </h3>
                            <div className="flex flex-wrap gap-2">
                                {items.map((item) => (
                                    <span
                                        key={item}
                                        className="px-3 py-1.5 rounded-lg text-sm"
                                        style={{
                                            background: 'rgba(255,255,255,0.04)',
                                            border: '1px solid var(--border)',
                                            color: 'var(--text-secondary)',
                                            fontFamily: 'DM Sans',
                                        }}
                                    >
                                        {item}
                                    </span>
                                ))}
                            </div>
                        </motion.div>
                    ))}
                </motion.div>

                {/* Tech logos strip */}
                <motion.div
                    variants={fadeUp}
                    initial="hidden"
                    whileInView="visible"
                    viewport={viewportConfig}
                    className="mt-12 flex flex-wrap justify-center gap-3"
                >
                    {['TypeScript', 'React Native', 'Expo', 'Firebase', 'Node.js', 'MongoDB', 'Fastlane', 'Figma'].map((tech) => (
                        <div
                            key={tech}
                            className="tag"
                        >
                            {tech}
                        </div>
                    ))}
                </motion.div>
            </div>
        </section>
    )
}