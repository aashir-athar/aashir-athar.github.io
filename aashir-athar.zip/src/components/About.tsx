import { motion } from 'framer-motion'
import { MapPin, Coffee, Zap, Heart } from 'lucide-react'
import { fadeUp, slideLeft, slideRight, stagger, viewportConfig } from '../lib/motion'

export default function About() {
    return (
        <section id="about" className="py-32 relative">
            <div className="max-w-7xl mx-auto px-6">
                {/* Section label */}
                <motion.div
                    variants={fadeUp}
                    initial="hidden"
                    whileInView="visible"
                    viewport={viewportConfig}
                    className="flex items-center gap-4 mb-16"
                >
                    <span style={{ color: 'var(--cyan)', fontFamily: 'JetBrains Mono', fontSize: '0.8rem' }}>01.</span>
                    <h2 style={{ fontFamily: 'Syne', fontSize: '2rem', fontWeight: 700 }}>About Me</h2>
                    <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
                </motion.div>

                <div className="grid lg:grid-cols-2 gap-16 items-start">
                    {/* Left: Story */}
                    <motion.div
                        variants={stagger}
                        initial="hidden"
                        whileInView="visible"
                        viewport={viewportConfig}
                        className="space-y-5"
                    >
                        <motion.p variants={fadeUp} style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: '1.05rem' }}>
                            I'm a <span style={{ color: 'var(--text-primary)' }}>Senior React Native Developer</span> based in{' '}
                            <span style={{ color: 'var(--cyan)' }}>Lahore, Pakistan</span>, with over three years of experience
                            turning complex product ideas into performant, cross-platform mobile applications.
                        </motion.p>
                        <motion.p variants={fadeUp} style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: '1.05rem' }}>
                            My career spans startups and mid-sized tech firms across the US and Pakistan — leading app architecture,
                            shipping MVPs in 6–8 weeks, and mentoring junior developers. I've built apps that now serve{' '}
                            <span style={{ color: 'var(--text-primary)' }}>50,000+ active users</span> and deployed CI/CD pipelines
                            that cut manual errors by 90%.
                        </motion.p>
                        <motion.p variants={fadeUp} style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: '1.05rem' }}>
                            Beyond shipping features, I obsess over the details that make mobile apps feel{' '}
                            <em>magical</em> — 60fps gesture animations, thoughtful onboarding flows, sub-second load times, and
                            accessibility baked in from day one. Mobile isn't just a platform I work on; it's the lens through which
                            I see great software.
                        </motion.p>

                        {/* Quick facts */}
                        <motion.div variants={fadeUp} className="flex flex-wrap gap-4 pt-2">
                            {[
                                { icon: <MapPin size={14} />, text: 'Lahore, Pakistan' },
                                { icon: <Coffee size={14} />, text: 'Remote-first' },
                                { icon: <Zap size={14} />, text: 'TypeScript purist' },
                                { icon: <Heart size={14} />, text: 'Open source contributor' },
                            ].map(({ icon, text }) => (
                                <div
                                    key={text}
                                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm"
                                    style={{
                                        background: 'var(--bg-elevated)',
                                        border: '1px solid var(--border)',
                                        color: 'var(--text-secondary)',
                                    }}
                                >
                                    <span style={{ color: 'var(--cyan)' }}>{icon}</span>
                                    {text}
                                </div>
                            ))}
                        </motion.div>
                    </motion.div>

                    {/* Right: Highlights grid */}
                    <motion.div
                        variants={stagger}
                        initial="hidden"
                        whileInView="visible"
                        viewport={viewportConfig}
                        className="grid grid-cols-2 gap-4"
                    >
                        {[
                            {
                                number: '50K+',
                                label: 'Active Users',
                                detail: 'Across production apps I architected and led',
                            },
                            {
                                number: '90%',
                                label: 'Fewer Deploy Errors',
                                detail: 'After implementing Fastlane CI/CD pipelines',
                            },
                            {
                                number: '35%',
                                label: 'Faster App Load',
                                detail: 'Via lazy loading, image compression, nav refactoring',
                            },
                            {
                                number: '40%',
                                label: 'Faster Onboarding',
                                detail: 'Mentored 4 junior devs with modular coding standards',
                            },
                        ].map(({ number, label, detail }) => (
                            <motion.div
                                key={label}
                                variants={fadeUp}
                                className="glass glass-hover rounded-2xl p-5"
                            >
                                <div
                                    style={{
                                        fontFamily: 'Syne',
                                        fontSize: '2rem',
                                        fontWeight: 800,
                                        color: 'var(--cyan)',
                                        lineHeight: 1,
                                        marginBottom: 4,
                                    }}
                                >
                                    {number}
                                </div>
                                <div
                                    style={{
                                        fontSize: '0.85rem',
                                        fontWeight: 600,
                                        color: 'var(--text-primary)',
                                        marginBottom: 6,
                                    }}
                                >
                                    {label}
                                </div>
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>{detail}</div>
                            </motion.div>
                        ))}
                    </motion.div>
                </div>
            </div>
        </section>
    )
}